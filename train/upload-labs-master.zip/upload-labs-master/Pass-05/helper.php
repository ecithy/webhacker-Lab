<?php
if($_GET['action'] == 'get_prompt'){
    echo '上传目录存在php文件（readme.php）';
}
?>